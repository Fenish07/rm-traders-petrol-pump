import { MapPin, Phone, Star, Clock } from 'lucide-react';
import { STATION, HERO_IMAGE } from '@/data';

export default function Hero() {
  return (
    <section id="home" className="relative flex min-h-screen items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={HERO_IMAGE}
          alt="Petrol pump station"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-brand-950/80 via-brand-900/60 to-brand-950/85" />
        <div className="absolute inset-0 bg-gradient-to-r from-brand-950/70 to-transparent" />
      </div>

      <div className="relative z-10 mx-auto max-w-4xl px-4 py-32 text-center sm:px-6 lg:px-8">
        <div className="animate-fade-up inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-medium text-white backdrop-blur-md ring-1 ring-white/20">
          <Clock className="h-4 w-4 text-accent-400" />
          Open 24 Hours • Every Day
        </div>

        <h1
          className="animate-fade-up mt-6 font-display text-4xl font-extrabold leading-tight text-white text-shadow-lg sm:text-5xl md:text-6xl lg:text-7xl"
          style={{ animationDelay: '0.1s', animationFillMode: 'both' }}
        >
          {STATION.name}
          <span className="block mt-2 text-2xl font-semibold text-accent-400 sm:text-3xl md:text-4xl">
            Petrol Pump
          </span>
        </h1>

        <p
          className="animate-fade-up mx-auto mt-6 max-w-2xl text-lg text-white/90 text-shadow-lg sm:text-xl"
          style={{ animationDelay: '0.2s', animationFillMode: 'both' }}
        >
          {STATION.tagline}
        </p>

        <div
          className="animate-fade-up mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row"
          style={{ animationDelay: '0.3s', animationFillMode: 'both' }}
        >
          <a
            href={STATION.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-accent-500 px-8 py-4 text-base font-bold text-white shadow-xl transition-all duration-300 hover:bg-accent-600 hover:shadow-2xl hover:-translate-y-1 sm:w-auto"
          >
            <MapPin className="h-5 w-5 transition-transform group-hover:scale-110" />
            Get Directions
          </a>
          <a
            href={`tel:${STATION.phoneRaw}`}
            className="group inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-white px-8 py-4 text-base font-bold text-brand-800 shadow-xl transition-all duration-300 hover:bg-brand-50 hover:shadow-2xl hover:-translate-y-1 sm:w-auto"
          >
            <Phone className="h-5 w-5 transition-transform group-hover:scale-110" />
            Call Now
          </a>
        </div>

        <div
          className="animate-fade-up mt-10 flex items-center justify-center gap-2 text-white/90"
          style={{ animationDelay: '0.4s', animationFillMode: 'both' }}
        >
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4].map((i) => (
              <Star key={i} className="h-4 w-4 fill-accent-400 text-accent-400" />
            ))}
            <Star className="h-4 w-4 fill-accent-400/50 text-accent-400/50" />
          </div>
          <span className="text-sm font-medium">
            {STATION.rating.toFixed(1)} • {STATION.reviewCount} Google Reviews
          </span>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-white to-transparent" />
    </section>
  );
}
