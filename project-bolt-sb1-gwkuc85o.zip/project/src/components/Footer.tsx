import { Fuel, Clock, MapPin, Phone } from 'lucide-react';
import { STATION } from '@/data';

export default function Footer() {
  const handleNavClick = (href: string) => {
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="bg-brand-950 pt-16 pb-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 shadow-md">
                <Fuel className="h-5 w-5 text-white" />
              </div>
              <div>
                <span className="block font-display text-lg font-bold text-white">
                  {STATION.name}
                </span>
                <span className="block text-xs font-medium text-accent-400">Petrol Pump</span>
              </div>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-brand-300">
              Your trusted fuel partner on the highway. Quality fuel, clean facilities,
              and round-the-clock service for every traveler.
            </p>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-wider text-white">
              Quick Links
            </h3>
            <ul className="mt-4 space-y-2.5">
              {[
                { label: 'Home', href: '#home' },
                { label: 'About', href: '#about' },
                { label: 'Services', href: '#services' },
                { label: 'Gallery', href: '#gallery' },
                { label: 'Reviews', href: '#reviews' },
                { label: 'Contact', href: '#contact' },
              ].map((link) => (
                <li key={link.href}>
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="text-sm text-brand-300 transition-colors hover:text-accent-400"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-display text-sm font-bold uppercase tracking-wider text-white">
              Contact Info
            </h3>
            <ul className="mt-4 space-y-3.5">
              <li className="flex items-start gap-3 text-sm text-brand-300">
                <Clock className="mt-0.5 h-4 w-4 shrink-0 text-accent-400" />
                <span>{STATION.hours}</span>
              </li>
              <li className="flex items-start gap-3 text-sm text-brand-300">
                <Phone className="mt-0.5 h-4 w-4 shrink-0 text-accent-400" />
                <a href={`tel:${STATION.phoneRaw}`} className="hover:text-accent-400">
                  {STATION.phone}
                </a>
              </li>
              <li className="flex items-start gap-3 text-sm text-brand-300">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-accent-400" />
                <span>{STATION.address}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-brand-400">
              &copy; {new Date().getFullYear()} {STATION.fullName}. All rights reserved.
            </p>
            <p className="flex items-center gap-2 text-sm text-brand-400">
              <Clock className="h-4 w-4 text-accent-400" />
              Open 24 Hours
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
