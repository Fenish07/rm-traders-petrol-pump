import { Star, Quote } from 'lucide-react';
import { REVIEWS, STATION } from '@/data';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function Reviews() {
  const { ref, isVisible } = useScrollAnimation<HTMLDivElement>();

  return (
    <section id="reviews" className="bg-gradient-to-b from-gray-50 to-white py-20 sm:py-28">
      <div
        ref={ref}
        className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 ${isVisible ? 'is-visible' : ''} animate-on-scroll`}
      >
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-block rounded-full bg-accent-50 px-4 py-1.5 text-sm font-semibold text-accent-700">
            Customer Reviews
          </span>
          <h2 className="mt-4 font-display text-3xl font-bold text-brand-900 sm:text-4xl">
            What Our Customers Say
          </h2>
          <div className="mt-5 inline-flex items-center gap-3 rounded-full bg-white px-6 py-3 shadow-md ring-1 ring-gray-100">
            <span className="text-3xl font-bold text-brand-900">{STATION.rating.toFixed(1)}</span>
            <div className="flex flex-col items-start">
              <div className="flex items-center gap-0.5">
                {[1, 2, 3, 4].map((i) => (
                  <Star key={i} className="h-4 w-4 fill-accent-500 text-accent-500" />
                ))}
                <Star className="h-4 w-4 fill-accent-500/50 text-accent-500/50" />
              </div>
              <span className="mt-0.5 text-xs text-gray-500">
                {STATION.reviewCount} Google Reviews
              </span>
            </div>
          </div>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2">
          {REVIEWS.map((review) => (
            <div
              key={review.name}
              className="group relative rounded-2xl bg-white p-7 shadow-md ring-1 ring-gray-100 transition-all duration-300 hover:shadow-xl hover:-translate-y-1"
            >
              <Quote className="absolute right-6 top-6 h-10 w-10 text-brand-100" />
              <div className="flex items-center gap-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < review.rating
                        ? 'fill-accent-500 text-accent-500'
                        : 'fill-gray-200 text-gray-200'
                    }`}
                  />
                ))}
              </div>
              <p className="mt-4 text-sm leading-relaxed text-gray-600">"{review.text}"</p>
              <div className="mt-5 flex items-center gap-3 border-t border-gray-100 pt-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-brand-600 to-brand-800 text-sm font-bold text-white">
                  {review.name.charAt(0)}
                </div>
                <div>
                  <p className="font-semibold text-brand-900">{review.name}</p>
                  <p className="text-xs text-gray-400">{review.date}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
