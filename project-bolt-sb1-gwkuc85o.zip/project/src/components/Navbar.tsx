import { useEffect, useState } from 'react';
import { Menu, X, Fuel, Phone } from 'lucide-react';
import { STATION } from '@/data';

const NAV_LINKS = [
  { label: 'Home', href: '#home' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Gallery', href: '#gallery' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Contact', href: '#contact' },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    el?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? 'bg-white/95 shadow-lg backdrop-blur-md py-2'
          : 'bg-transparent py-4'
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => handleNavClick('#home')}
          className="flex items-center gap-2.5"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-brand-600 to-brand-800 shadow-md">
            <Fuel className="h-5 w-5 text-white" />
          </div>
          <div className="text-left">
            <span
              className={`block font-display text-lg font-bold leading-tight transition-colors ${
                scrolled ? 'text-brand-800' : 'text-white text-shadow-lg'
              }`}
            >
              {STATION.name}
            </span>
            <span
              className={`block text-xs font-medium leading-tight transition-colors ${
                scrolled ? 'text-accent-600' : 'text-accent-400'
              }`}
            >
              Petrol Pump
            </span>
          </div>
        </button>

        <ul className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <li key={link.href}>
              <button
                onClick={() => handleNavClick(link.href)}
                className={`rounded-lg px-4 py-2 text-sm font-semibold transition-all duration-300 hover:bg-brand-50 ${
                  scrolled
                    ? 'text-brand-800 hover:text-brand-600'
                    : 'text-white/90 text-shadow-lg hover:bg-white/10 hover:text-white'
                }`}
              >
                {link.label}
              </button>
            </li>
          ))}
        </ul>

        <div className="hidden lg:block">
          <a
            href={`tel:${STATION.phoneRaw}`}
            className="inline-flex items-center gap-2 rounded-full bg-accent-500 px-5 py-2.5 text-sm font-semibold text-white shadow-md transition-all duration-300 hover:bg-accent-600 hover:shadow-lg hover:-translate-y-0.5"
          >
            <Phone className="h-4 w-4" />
            Call Now
          </a>
        </div>

        <button
          onClick={() => setMenuOpen(!menuOpen)}
          className={`rounded-lg p-2 transition-colors lg:hidden ${
            scrolled ? 'text-brand-800' : 'text-white'
          }`}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      <div
        className={`overflow-hidden transition-all duration-500 lg:hidden ${
          menuOpen ? 'max-h-[400px]' : 'max-h-0'
        }`}
      >
        <div className="mx-4 mt-3 rounded-2xl bg-white p-4 shadow-xl">
          <ul className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <li key={link.href}>
                <button
                  onClick={() => handleNavClick(link.href)}
                  className="w-full rounded-lg px-4 py-3 text-left text-sm font-semibold text-brand-800 transition-colors hover:bg-brand-50"
                >
                  {link.label}
                </button>
              </li>
            ))}
            <li className="mt-2">
              <a
                href={`tel:${STATION.phoneRaw}`}
                className="flex items-center justify-center gap-2 rounded-full bg-accent-500 px-5 py-3 text-sm font-semibold text-white"
              >
                <Phone className="h-4 w-4" />
                Call Now
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
