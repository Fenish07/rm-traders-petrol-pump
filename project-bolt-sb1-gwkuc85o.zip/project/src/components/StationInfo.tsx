import { Clock, Star, Phone, MapPin, Users } from 'lucide-react';
import { STATION } from '@/data';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function StationInfo() {
  const { ref, isVisible } = useScrollAnimation<HTMLDivElement>();

  return (
    <section className="bg-brand-950 py-20 sm:py-24">
      <div
        ref={ref}
        className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 ${isVisible ? 'is-visible' : ''} animate-on-scroll`}
      >
        <div className="text-center">
          <span className="inline-block rounded-full bg-white/10 px-4 py-1.5 text-sm font-semibold text-brand-200 ring-1 ring-white/20">
            Station Information
          </span>
          <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl">
            Visit R.M. TRADERS Petrol Pump
          </h2>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl bg-white/5 p-7 text-center ring-1 ring-white/10 transition-all duration-300 hover:bg-white/10 hover:-translate-y-1">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-accent-500 shadow-lg">
              <Clock className="h-7 w-7 text-white" />
            </div>
            <h3 className="mt-5 font-display text-lg font-bold text-white">Open 24 Hours</h3>
            <p className="mt-2 text-sm text-brand-200">Every day, all year round</p>
          </div>

          <div className="rounded-2xl bg-white/5 p-7 text-center ring-1 ring-white/10 transition-all duration-300 hover:bg-white/10 hover:-translate-y-1">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-accent-500 shadow-lg">
              <Star className="h-7 w-7 text-white" />
            </div>
            <h3 className="mt-5 font-display text-lg font-bold text-white">
              {STATION.rating.toFixed(1)} Star Rating
            </h3>
            <div className="mt-2 flex items-center justify-center gap-1">
              {[1, 2, 3, 4].map((i) => (
                <Star key={i} className="h-4 w-4 fill-accent-400 text-accent-400" />
              ))}
              <Star className="h-4 w-4 fill-accent-400/50 text-accent-400/50" />
            </div>
          </div>

          <div className="rounded-2xl bg-white/5 p-7 text-center ring-1 ring-white/10 transition-all duration-300 hover:bg-white/10 hover:-translate-y-1">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-accent-500 shadow-lg">
              <Users className="h-7 w-7 text-white" />
            </div>
            <h3 className="mt-5 font-display text-lg font-bold text-white">
              {STATION.reviewCount} Reviews
            </h3>
            <p className="mt-2 text-sm text-brand-200">Based on Google Reviews</p>
          </div>

          <div className="rounded-2xl bg-white/5 p-7 text-center ring-1 ring-white/10 transition-all duration-300 hover:bg-white/10 hover:-translate-y-1">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-accent-500 shadow-lg">
              <Phone className="h-7 w-7 text-white" />
            </div>
            <h3 className="mt-5 font-display text-lg font-bold text-white">Call Us</h3>
            <a
              href={`tel:${STATION.phoneRaw}`}
              className="mt-2 block text-sm font-medium text-brand-200 hover:text-white"
            >
              {STATION.phone}
            </a>
          </div>
        </div>

        <div className="mt-8 flex flex-col items-center gap-4 rounded-2xl bg-white/5 p-7 ring-1 ring-white/10 sm:flex-row sm:gap-6">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-accent-500 shadow-lg">
            <MapPin className="h-7 w-7 text-white" />
          </div>
          <div className="flex-1 text-center sm:text-left">
            <h3 className="font-display text-lg font-bold text-white">Our Location</h3>
            <p className="mt-1.5 text-sm text-brand-200">{STATION.address}</p>
          </div>
          <a
            href={STATION.mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 text-sm font-bold text-brand-800 shadow-md transition-all hover:bg-brand-50 hover:-translate-y-0.5"
          >
            <MapPin className="h-4 w-4" />
            View on Map
          </a>
        </div>
      </div>
    </section>
  );
}
