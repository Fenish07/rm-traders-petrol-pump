import { Clock, ShieldCheck, HeartHandshake, Fuel } from 'lucide-react';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const FEATURES = [
  {
    icon: Clock,
    title: '24/7 Availability',
    text: 'We never close. Whether it is the break of dawn or the middle of the night, our pumps are always ready to serve you.',
  },
  {
    icon: ShieldCheck,
    title: 'Trusted Fuel Quality',
    text: 'Calibrated, quality-assured fuel sourced from reliable channels — giving your vehicle the performance it deserves.',
  },
  {
    icon: HeartHandshake,
    title: 'Customer-First Service',
    text: 'Our trained staff is committed to courteous, efficient service that makes every visit quick and pleasant.',
  },
];

export default function About() {
  const { ref, isVisible } = useScrollAnimation<HTMLDivElement>();

  return (
    <section id="about" className="bg-white py-20 sm:py-28">
      <div
        ref={ref}
        className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 ${isVisible ? 'is-visible' : ''} animate-on-scroll`}
      >
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          <div>
            <span className="inline-block rounded-full bg-brand-50 px-4 py-1.5 text-sm font-semibold text-brand-700">
              About Us
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold text-brand-900 sm:text-4xl">
              Your Trusted Fuel Partner on the Highway
            </h2>
            <p className="mt-6 text-lg leading-relaxed text-gray-600">
              R.M. TRADERS Petrol Pump has been serving travelers, commuters, and
              commercial fleets with reliable fuel and genuine care. Strategically
              located on the highway, we ensure you are never far from a quality
              fill-up — any time of day or night.
            </p>
            <p className="mt-4 text-lg leading-relaxed text-gray-600">
              From accurate dispensing to clean facilities and digital payment
              convenience, every detail is designed to make your stop efficient and
              comfortable.
            </p>

            <div className="mt-8 flex items-center gap-6">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent-50">
                  <Fuel className="h-6 w-6 text-accent-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-brand-900">24/7</p>
                  <p className="text-sm text-gray-500">Always Open</p>
                </div>
              </div>
              <div className="h-12 w-px bg-gray-200" />
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50">
                  <ShieldCheck className="h-6 w-6 text-brand-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-brand-900">100%</p>
                  <p className="text-sm text-gray-500">Quality Assured</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid gap-6">
            {FEATURES.map((feature) => (
              <div
                key={feature.title}
                className="group flex gap-5 rounded-2xl border border-gray-100 bg-gradient-to-br from-white to-gray-50 p-6 shadow-sm transition-all duration-300 hover:shadow-lg hover:border-brand-200"
              >
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-brand-600 shadow-md transition-transform group-hover:scale-110">
                  <feature.icon className="h-7 w-7 text-white" />
                </div>
                <div>
                  <h3 className="font-display text-lg font-bold text-brand-900">
                    {feature.title}
                  </h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-gray-600">
                    {feature.text}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
