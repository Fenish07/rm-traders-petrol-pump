import { Phone, MapPin, Share2 } from 'lucide-react';
import { STATION } from '@/data';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

export default function Contact() {
  const { ref, isVisible } = useScrollAnimation<HTMLDivElement>();

  const handleShare = async () => {
    const shareData = {
      title: STATION.fullName,
      text: STATION.tagline,
      url: STATION.mapsUrl,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        /* user cancelled */
      }
    } else {
      try {
        await navigator.clipboard.writeText(`${STATION.fullName} - ${STATION.mapsUrl}`);
        alert('Link copied to clipboard!');
      } catch {
        /* clipboard not available */
      }
    }
  };

  return (
    <section id="contact" className="bg-white py-20 sm:py-28">
      <div
        ref={ref}
        className={`mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 ${isVisible ? 'is-visible' : ''} animate-on-scroll`}
      >
        <div className="overflow-hidden rounded-3xl bg-gradient-to-br from-brand-800 via-brand-900 to-brand-950 shadow-2xl">
          <div className="px-6 py-14 text-center sm:px-12 sm:py-20">
            <span className="inline-block rounded-full bg-white/10 px-4 py-1.5 text-sm font-semibold text-brand-200 ring-1 ring-white/20">
              Contact Us
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold text-white sm:text-4xl">
              Need Fuel? We Are Here for You.
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-lg text-brand-200">
              Call us, get directions, or share our location with fellow travelers. We are always ready to help.
            </p>

            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <a
                href={`tel:${STATION.phoneRaw}`}
                className="inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-accent-500 px-8 py-4 text-base font-bold text-white shadow-xl transition-all duration-300 hover:bg-accent-600 hover:-translate-y-1 hover:shadow-2xl sm:w-auto"
              >
                <Phone className="h-5 w-5" />
                Call Station
              </a>
              <a
                href={STATION.mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex w-full items-center justify-center gap-2.5 rounded-full bg-white px-8 py-4 text-base font-bold text-brand-800 shadow-xl transition-all duration-300 hover:bg-brand-50 hover:-translate-y-1 hover:shadow-2xl sm:w-auto"
              >
                <MapPin className="h-5 w-5" />
                Get Directions
              </a>
              <button
                onClick={handleShare}
                className="inline-flex w-full items-center justify-center gap-2.5 rounded-full border-2 border-white/30 px-8 py-4 text-base font-bold text-white shadow-xl transition-all duration-300 hover:bg-white/10 hover:-translate-y-1 hover:shadow-2xl sm:w-auto"
              >
                <Share2 className="h-5 w-5" />
                Share
              </button>
            </div>

            <div className="mt-10 flex flex-col items-center gap-2 text-brand-200">
              <p className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-accent-400" />
                {STATION.phone}
              </p>
              <p className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-accent-400" />
                {STATION.address}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
