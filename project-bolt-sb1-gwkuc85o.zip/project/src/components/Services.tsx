import { Fuel, Truck, Wind, Sparkles, Smartphone, Clock } from 'lucide-react';
import { SERVICES } from '@/data';
import { useScrollAnimation } from '@/hooks/useScrollAnimation';

const ICONS: Record<string, typeof Fuel> = {
  Fuel,
  Truck,
  Wind,
  Sparkles,
  Smartphone,
  Clock,
};

export default function Services() {
  const { ref, isVisible } = useScrollAnimation<HTMLDivElement>();

  return (
    <section id="services" className="bg-gradient-to-b from-gray-50 to-white py-20 sm:py-28">
      <div
        ref={ref}
        className={`mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 ${isVisible ? 'is-visible' : ''} animate-on-scroll`}
      >
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-block rounded-full bg-accent-50 px-4 py-1.5 text-sm font-semibold text-accent-700">
            Our Services
          </span>
          <h2 className="mt-4 font-display text-3xl font-bold text-brand-900 sm:text-4xl">
            Everything You Need on the Road
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            From quality fuel to clean facilities and modern payment options — we have got every traveler covered.
          </p>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SERVICES.map((service, i) => {
            const Icon = ICONS[service.icon];
            return (
              <div
                key={service.title}
                className="group relative overflow-hidden rounded-2xl bg-white p-7 shadow-md ring-1 ring-gray-100 transition-all duration-300 hover:shadow-xl hover:-translate-y-1.5"
                style={{ transitionDelay: `${i * 50}ms` }}
              >
                <div className="absolute right-0 top-0 h-24 w-24 -translate-y-8 translate-x-8 rounded-full bg-brand-50 opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                <div className="relative">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-600 to-brand-800 shadow-lg transition-transform duration-300 group-hover:scale-110 group-hover:rotate-3">
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="mt-5 font-display text-xl font-bold text-brand-900">
                    {service.title}
                  </h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-gray-600">
                    {service.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
