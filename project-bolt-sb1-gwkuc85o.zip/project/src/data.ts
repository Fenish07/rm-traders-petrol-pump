export const STATION = {
  name: 'R.M. TRADERS',
  fullName: 'R.M. TRADERS Petrol Pump',
  tagline: 'Quality Fuel. Trusted Service. Open 24 Hours.',
  phone: '+91 98765 43210',
  phoneRaw: '+919876543210',
  address: 'NH-44 Highway, Near Bypass Junction, Industrial Area, Delhi 110001',
  rating: 4.0,
  reviewCount: 181,
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=petrol+pump+NH-44+Delhi',
  hours: 'Open 24 Hours • Every Day',
};

export const HERO_IMAGE =
  'https://images.pexels.com/photos/4624236/pexels-photo-4624236.jpeg?auto=compress&cs=tinysrgb&w=1920';

export const GALLERY_IMAGES = [
  {
    src: 'https://images.pexels.com/photos/10158866/pexels-photo-10158866.jpeg?auto=compress&cs=tinysrgb&w=1200',
    alt: 'Petrol station canopy against clear sky',
    caption: 'Station Canopy',
  },
  {
    src: 'https://images.pexels.com/photos/28700859/pexels-photo-28700859.jpeg?auto=compress&cs=tinysrgb&w=1200',
    alt: 'Fuel pumps at the station on a sunny day',
    caption: 'Fuel Pumps',
  },
  {
    src: 'https://images.pexels.com/photos/36078557/pexels-photo-36078557.jpeg?auto=compress&cs=tinysrgb&w=1200',
    alt: 'Gas station at night with neon lights',
    caption: 'Night View',
  },
  {
    src: 'https://images.pexels.com/photos/19224101/pexels-photo-19224101.jpeg?auto=compress&cs=tinysrgb&w=1200',
    alt: 'Auto rickshaw being refueled at gas station in India',
    caption: 'Daily Service',
  },
];

export const SERVICES = [
  {
    icon: 'Fuel',
    title: 'Petrol',
    description: 'Premium quality petrol with accurate, calibrated dispensers for every vehicle.',
  },
  {
    icon: 'Truck',
    title: 'Diesel',
    description: 'High-grade diesel fuel for commercial vehicles, trucks, and heavy machinery.',
  },
  {
    icon: 'Wind',
    title: 'Air Facility',
    description: 'Free air filling facility for cars, bikes, and commercial vehicles — always available.',
  },
  {
    icon: 'Sparkles',
    title: 'Clean Restroom',
    description: 'Well-maintained, hygienic restrooms for the comfort of all our customers.',
  },
  {
    icon: 'Smartphone',
    title: 'Digital Payments',
    description: 'Pay conveniently with UPI, cards, and all major digital payment methods.',
  },
  {
    icon: 'Clock',
    title: '24 Hour Service',
    description: 'Round-the-clock fuel and assistance, so you are never stranded on the road.',
  },
];

export const REVIEWS = [
  {
    name: 'Rajesh Kumar',
    rating: 5,
    date: '2 weeks ago',
    text: 'Excellent service and always open. The staff is very polite and the fuel quality is top-notch. Digital payment makes it so convenient during late-night drives.',
  },
  {
    name: 'Priya Sharma',
    rating: 4,
    date: '1 month ago',
    text: 'Good petrol pump with clean restrooms and air facility. The location is convenient on the highway. Prices are fair and the staff is helpful.',
  },
  {
    name: 'Mohammed Irfan',
    rating: 5,
    date: '1 month ago',
    text: 'One of the best fuel stations on this route. Open 24 hours which is a lifesaver for truck drivers like me. Diesel quality is consistently good.',
  },
  {
    name: 'Anita Desai',
    rating: 4,
    date: '2 months ago',
    text: 'Well-maintained station with proper facilities. The restroom was clean and they accept all UPI payments. Recommended for highway travelers.',
  },
];
